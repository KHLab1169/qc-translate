import m08_sets_tuples as m


def test_common_tags():
    assert m.common_tags(["ui", "api", "slow"], ["api", "ui"]) == ["api", "ui"]
    assert m.common_tags(["a"], ["b"]) == []


def test_only_in_first():
    assert m.only_in_first(["ui", "api", "slow"], ["api"]) == ["slow", "ui"]
    assert m.only_in_first([], ["api"]) == []


def test_squares_of_odds():
    assert m.squares_of_odds(10) == [1, 9, 25, 49, 81]
    assert m.squares_of_odds(0) == []


def test_adjacent_pairs():
    assert m.adjacent_pairs([1, 2, 3]) == [(1, 2), (2, 3)]
    assert m.adjacent_pairs([1]) == []
    assert m.adjacent_pairs([]) == []
