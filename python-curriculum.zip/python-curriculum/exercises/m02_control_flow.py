"""Module 02 - Booleans, if/elif/else, comparison and logical operators."""


def letter_grade(score):
    """Map 0-100 to a letter: 90+ A, 80+ B, 70+ C, 60+ D, else F."""
    raise NotImplementedError("TODO: implement letter_grade")


def fizzbuzz(n):
    """Return "Fizz", "Buzz", "FizzBuzz" or str(n) for an integer n."""
    raise NotImplementedError("TODO: implement fizzbuzz")


def triage(severity, reproducible):
    """Return a bug priority string.

    severity is one of "critical", "major", "minor".
    Critical bugs are always "P1".
    Major bugs are "P2" when reproducible, otherwise "P3".
    Anything else is "P4".
    """
    raise NotImplementedError("TODO: implement triage")


def safe_divide(a, b):
    """Return a / b, or None if b is zero. Use try/except rather than an if."""
    raise NotImplementedError("TODO: implement safe_divide")
