"""Module 01 - Variables, types, numbers, strings, f-strings."""


def greet(name):
    """Return a greeting: greet("Ada") -> "Hello, Ada!" """
    raise NotImplementedError("TODO: implement greet")


def celsius_to_fahrenheit(celsius):
    """Convert Celsius to Fahrenheit and return a float."""
    raise NotImplementedError("TODO: implement celsius_to_fahrenheit")


def seconds_to_hms(total_seconds):
    """Format whole seconds as "H:MM:SS", e.g. 3661 -> "1:01:01"."""
    raise NotImplementedError("TODO: implement seconds_to_hms")


def pass_rate(passed, total):
    """Return the percentage of tests passed, rounded to 1 decimal place.

    A total of 0 returns 0.0 rather than raising.
    """
    raise NotImplementedError("TODO: implement pass_rate")
