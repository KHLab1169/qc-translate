"""Module 03 - Lists: indexing, slicing, methods, sorting."""


def second_largest(numbers):
    """Return the second largest distinct value, or None if there isn't one."""
    unique = sorted(set(numbers), reverse=True)
    if len(unique) < 2:
        return None
    return unique[1]


def dedupe(items):
    """Remove duplicates while preserving the original order."""
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def chunk(items, size):
    """Split a list into consecutive chunks of at most `size` items."""
    return [items[i:i + size] for i in range(0, len(items), size)]


def flatten_once(nested):
    """Flatten one level: [[1, 2], [3]] -> [1, 2, 3]."""
    return [item for sublist in nested for item in sublist]
