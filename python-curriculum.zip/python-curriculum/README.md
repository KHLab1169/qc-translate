# python-curriculum

A self-grading Python 3 curriculum. Read `CURRICULUM.md` for the syllabus; this file is just setup.

## Layout

```
CURRICULUM.md      the 18-module syllabus
exercises/         stub functions — this is where you write code
tests/             pytest suites that grade the stubs (85 checks)
solutions/         reference answers — open only after you've passed
conftest.py        points the tests at exercises/ by default
progress.py        per-module progress bars
```

## Setup (fish)

```fish
cd python-curriculum
python3 -m venv .venv
source .venv/bin/activate.fish
pip install pytest
```

Later sessions only need the `source` line. To leave the venv, run `deactivate`.

## Working through it

```fish
python3 -m pytest tests/test_m01_basics.py -q    # grade one module
python3 -m pytest -q                             # grade everything
python3 -m pytest -q -x                          # stop at the first failure
python3 -m pytest tests/test_m03_lists.py -k chunk -vv   # one function, verbose
python3 progress.py                              # where am I
```

Everything fails on a fresh checkout. That's the starting line, not a problem — each failure is `NotImplementedError` until you replace the stub body in `exercises/`.

## Reading a failure

```
E       AssertionError: assert 'Hello Ada' == 'Hello, Ada!'
E         - Hello, Ada!
E         + Hello Ada
tests/test_m01_basics.py:6: AssertionError
```

The `-` line is what was expected, the `+` line is what your code returned, and the last line is the file and line number of the check. Nothing else in the output matters until you've read those three things.

## Checking the reference answers

```fish
SOLUTIONS=1 python3 -m pytest -q     # grades solutions/ instead of exercises/
```

All 85 pass. Useful for confirming the harness works, or for diffing your approach against the reference once a module is green.

## A note on the solutions

They're written to be readable rather than clever — no one-liners where three clear lines do. If your version passes and reads well, it's correct even if it looks nothing like the reference. There is usually more than one right answer, and the tests are deliberately written against behaviour, not implementation.
