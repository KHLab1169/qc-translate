import m10_classes as m


def test_stack_is_lifo():
    stack = m.Stack()
    stack.push("a")
    stack.push("b")
    assert len(stack) == 2
    assert stack.peek() == "b"
    assert stack.pop() == "b"
    assert stack.pop() == "a"
    assert len(stack) == 0


def test_empty_stack_returns_none():
    stack = m.Stack()
    assert stack.pop() is None
    assert stack.peek() is None


def test_test_case_steps():
    case = m.TestCase("Login")
    case.add_step("open app").add_step("enter password")
    assert len(case) == 2
    assert case.steps == ["open app", "enter password"]


def test_test_case_copies_starting_steps():
    steps = ["one"]
    case = m.TestCase("Login", steps)
    case.add_step("two")
    assert steps == ["one"], "the caller's list must not be modified"


def test_test_case_repr_and_equality():
    left = m.TestCase("Login", ["a", "b"])
    right = m.TestCase("Login", ["a", "b"])
    assert repr(left) == "TestCase('Login', steps=2)"
    assert left == right
    assert left != m.TestCase("Logout", ["a", "b"])
    assert left != "Login"


def test_timed_test_case_inherits():
    case = m.TimedTestCase("Login", 45.0, ["a"])
    assert isinstance(case, m.TestCase)
    assert case.is_slow is True
    assert m.TimedTestCase("Fast", 1.0).is_slow is False
    case.add_step("b")
    assert repr(case) == "TimedTestCase('Login', 45.0s, steps=2)"
