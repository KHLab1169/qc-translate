"""Module 10 - Classes, dunder methods, inheritance and properties."""


class Stack:
    """A last-in first-out stack built on a list."""

    def __init__(self):
        """Start with an empty stack."""
        self._items = []

    def push(self, item):
        """Add an item to the top."""
        self._items.append(item)

    def pop(self):
        """Remove and return the top item, or None when empty."""
        if not self._items:
            return None
        return self._items.pop()

    def peek(self):
        """Return the top item without removing it, or None when empty."""
        if not self._items:
            return None
        return self._items[-1]

    def __len__(self):
        """Support len(stack)."""
        return len(self._items)


class TestCase:
    """A named test case with an ordered list of steps."""

    def __init__(self, name, steps=None):
        """Store the name and a copy of any starting steps."""
        self.name = name
        self.steps = list(steps) if steps else []

    def add_step(self, step):
        """Append a step and return self so calls can be chained."""
        self.steps.append(step)
        return self

    def __len__(self):
        """The number of steps."""
        return len(self.steps)

    def __repr__(self):
        """Return e.g. TestCase('Login', steps=2)."""
        return f"TestCase({self.name!r}, steps={len(self.steps)})"

    def __eq__(self, other):
        """Two test cases are equal when name and steps match."""
        if not isinstance(other, TestCase):
            return NotImplemented
        return self.name == other.name and self.steps == other.steps


class TimedTestCase(TestCase):
    """A test case that also records how long it ran, in seconds."""

    def __init__(self, name, duration, steps=None):
        """Call the parent initialiser, then store the duration."""
        super().__init__(name, steps)
        self.duration = duration

    @property
    def is_slow(self):
        """True when the run took longer than 30 seconds."""
        return self.duration > 30

    def __repr__(self):
        """Return e.g. TimedTestCase('Login', 12.5s, steps=2)."""
        return f"TimedTestCase({self.name!r}, {self.duration}s, steps={len(self.steps)})"
