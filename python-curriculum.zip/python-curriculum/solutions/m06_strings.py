"""Module 06 - String methods, slicing, split and join."""


def normalize_whitespace(text):
    """Collapse runs of whitespace into single spaces and strip the ends."""
    return " ".join(text.split())


def is_palindrome(text):
    """True if the text reads the same backwards, ignoring case and punctuation."""
    cleaned = [char.lower() for char in text if char.isalnum()]
    return cleaned == cleaned[::-1]


def initials(full_name):
    """Return dotted uppercase initials: "ada lovelace" -> "A.L."

    An empty or whitespace-only name returns "".
    """
    parts = full_name.split()
    if not parts:
        return ""
    return "".join(f"{part[0].upper()}." for part in parts)


def parse_log_line(line):
    """Split "2026-01-31 12:00:00 ERROR Disk full" into a dict.

    Returns {"date":..., "time":..., "level":..., "message":...}.
    The message keeps its internal spacing and may contain spaces.
    """
    date, time, level, message = line.split(" ", 3)
    return {"date": date, "time": time, "level": level, "message": message}
