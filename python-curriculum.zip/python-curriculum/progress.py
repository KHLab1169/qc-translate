#!/usr/bin/env python3
"""Show how far through the exercises you are.

    python3 progress.py
"""
import pathlib
import subprocess
import sys

ROOT = pathlib.Path(__file__).parent
TESTS = sorted((ROOT / "tests").glob("test_m*.py"))

total_passed = total_count = 0
print()
for test_file in TESTS:
    result = subprocess.run(
        [sys.executable, "-m", "pytest", str(test_file), "-q", "--no-header", "-p", "no:cacheprovider"],
        capture_output=True, text=True, cwd=ROOT,
    )
    summary = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else ""
    passed = int(summary.split(" passed")[0].split()[-1]) if "passed" in summary else 0
    failed = int(summary.split(" failed")[0].split()[-1]) if "failed" in summary else 0
    count = passed + failed
    total_passed += passed
    total_count += count
    filled = round(passed / count * 20) if count else 0
    bar = "#" * filled + "." * (20 - filled)
    mark = "DONE" if passed == count else "    "
    print(f"  {test_file.stem[5:]:<20} [{bar}] {passed:>2}/{count:<2} {mark}")

print(f"\n  TOTAL: {total_passed}/{total_count} checks passing\n")
