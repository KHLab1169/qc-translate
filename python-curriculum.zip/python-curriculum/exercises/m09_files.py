"""Module 09 - Files, context managers, CSV and JSON."""
import csv
import json


def write_lines(path, lines):
    """Write each line to the file at path, one per line, and return the count."""
    raise NotImplementedError("TODO: implement write_lines")


def count_lines_matching(path, substring):
    """Count the lines in the file that contain the substring."""
    raise NotImplementedError("TODO: implement count_lines_matching")


def read_json_field(path, key, default=None):
    """Return the top-level key from a JSON object file, or default if absent."""
    raise NotImplementedError("TODO: implement read_json_field")


def csv_column_sum(path, column):
    """Sum a numeric column in a CSV file that has a header row."""
    raise NotImplementedError("TODO: implement csv_column_sum")
