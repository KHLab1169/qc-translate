import m03_lists as m


def test_second_largest():
    assert m.second_largest([3, 1, 4, 1, 5]) == 4
    assert m.second_largest([7, 7, 2]) == 2
    assert m.second_largest([9]) is None
    assert m.second_largest([4, 4, 4]) is None


def test_dedupe_preserves_order():
    assert m.dedupe(["b", "a", "b", "c", "a"]) == ["b", "a", "c"]
    assert m.dedupe([]) == []


def test_dedupe_does_not_mutate_input():
    original = [1, 1, 2]
    m.dedupe(original)
    assert original == [1, 1, 2]


def test_chunk():
    assert m.chunk([1, 2, 3, 4, 5], 2) == [[1, 2], [3, 4], [5]]
    assert m.chunk([1, 2, 3], 5) == [[1, 2, 3]]
    assert m.chunk([], 3) == []


def test_flatten_once():
    assert m.flatten_once([[1, 2], [3], []]) == [1, 2, 3]
    assert m.flatten_once([[[1]], [2]]) == [[1], 2]
