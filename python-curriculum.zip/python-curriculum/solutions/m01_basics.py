"""Module 01 - Variables, types, numbers, strings, f-strings."""


def greet(name):
    """Return a greeting: greet("Ada") -> "Hello, Ada!" """
    return f"Hello, {name}!"


def celsius_to_fahrenheit(celsius):
    """Convert Celsius to Fahrenheit and return a float."""
    return celsius * 9 / 5 + 32


def seconds_to_hms(total_seconds):
    """Format whole seconds as "H:MM:SS", e.g. 3661 -> "1:01:01"."""
    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours}:{minutes:02d}:{seconds:02d}"


def pass_rate(passed, total):
    """Return the percentage of tests passed, rounded to 1 decimal place.

    A total of 0 returns 0.0 rather than raising.
    """
    if total == 0:
        return 0.0
    return round(passed / total * 100, 1)
