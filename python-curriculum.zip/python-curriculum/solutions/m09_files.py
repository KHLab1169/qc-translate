"""Module 09 - Files, context managers, CSV and JSON."""
import csv
import json


def write_lines(path, lines):
    """Write each line to the file at path, one per line, and return the count."""
    with open(path, "w", encoding="utf-8") as handle:
        for line in lines:
            handle.write(f"{line}\n")
    return len(lines)


def count_lines_matching(path, substring):
    """Count the lines in the file that contain the substring."""
    count = 0
    with open(path, encoding="utf-8") as handle:
        for line in handle:
            if substring in line:
                count += 1
    return count


def read_json_field(path, key, default=None):
    """Return the top-level key from a JSON object file, or default if absent."""
    with open(path, encoding="utf-8") as handle:
        data = json.load(handle)
    return data.get(key, default)


def csv_column_sum(path, column):
    """Sum a numeric column in a CSV file that has a header row."""
    total = 0.0
    with open(path, newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            total += float(row[column])
    return total
