"""Module 12 - Exceptions: raising, catching, custom types and cleanup."""


class ValidationError(ValueError):
    """Raised when input fails validation."""


def parse_positive_int(text):
    """Return the int in text, or raise ValidationError with a helpful message.

    Both non-numeric text and values below 1 are invalid.
    """
    raise NotImplementedError("TODO: implement parse_positive_int")


def retry(func, attempts=3):
    """Call func until it returns without raising.

    Return its value on success. If every attempt raises, re-raise the last error.
    """
    raise NotImplementedError("TODO: implement retry")


def collect_errors(items, validator):
    """Run validator on each item and collect the failures.

    Return a list of (item, message) for the items that raised, in order.
    """
    raise NotImplementedError("TODO: implement collect_errors")
