"""Module 05 - Functions: defaults, *args, **kwargs, closures, first-class functions."""


def apply_twice(func, value):
    """Call func on value, then call func on the result, and return it."""
    raise NotImplementedError("TODO: implement apply_twice")


def summarize(*numbers):
    """Return (minimum, maximum, mean) for the numbers given.

    Return (None, None, None) when called with no arguments.
    """
    raise NotImplementedError("TODO: implement summarize")


def build_url(base, **params):
    """Append query parameters to a base URL, sorted by key.

    build_url("http://x.dev", b=2, a=1) -> "http://x.dev?a=1&b=2"
    With no params, return base unchanged.
    """
    raise NotImplementedError("TODO: implement build_url")


def make_counter(start=0):
    """Return a function that returns start, start + 1, start + 2 ... on each call."""
    raise NotImplementedError("TODO: implement make_counter")
