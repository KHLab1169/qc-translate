"""Module 11 - The standard library: datetime, collections, pathlib, random."""
import random
from collections import Counter
from datetime import date
from pathlib import Path


def days_between(first, second):
    """Return the absolute number of days between two date objects."""
    raise NotImplementedError("TODO: implement days_between")


def parse_iso_date(text):
    """Parse "2026-01-31" into a date object."""
    raise NotImplementedError("TODO: implement parse_iso_date")


def most_common_levels(lines, n):
    """Return the n most common log levels as (level, count) pairs.

    Each line looks like "ERROR something happened"; the level is the first word.
    """
    raise NotImplementedError("TODO: implement most_common_levels")


def deterministic_sample(items, k, seed):
    """Return k items chosen with a seeded Random instance, so runs repeat."""
    raise NotImplementedError("TODO: implement deterministic_sample")


def find_files(root, suffix):
    """Return sorted relative path strings of files under root with that suffix."""
    raise NotImplementedError("TODO: implement find_files")
