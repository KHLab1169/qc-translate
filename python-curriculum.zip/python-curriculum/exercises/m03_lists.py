"""Module 03 - Lists: indexing, slicing, methods, sorting."""


def second_largest(numbers):
    """Return the second largest distinct value, or None if there isn't one."""
    raise NotImplementedError("TODO: implement second_largest")


def dedupe(items):
    """Remove duplicates while preserving the original order."""
    raise NotImplementedError("TODO: implement dedupe")


def chunk(items, size):
    """Split a list into consecutive chunks of at most `size` items."""
    raise NotImplementedError("TODO: implement chunk")


def flatten_once(nested):
    """Flatten one level: [[1, 2], [3]] -> [1, 2, 3]."""
    raise NotImplementedError("TODO: implement flatten_once")
