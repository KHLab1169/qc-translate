import m05_functions as m
import pytest


def test_apply_twice():
    assert m.apply_twice(lambda x: x + 3, 1) == 7
    assert m.apply_twice(str.upper, "ab") == "AB"


def test_summarize():
    assert m.summarize(4, 1, 7) == (1, 7, 4.0)
    assert m.summarize(5) == (5, 5, 5.0)
    assert m.summarize() == (None, None, None)


def test_build_url():
    assert m.build_url("http://x.dev") == "http://x.dev"
    assert m.build_url("http://x.dev", b=2, a=1) == "http://x.dev?a=1&b=2"
    assert m.build_url("http://x.dev", page=3) == "http://x.dev?page=3"


def test_make_counter():
    counter = m.make_counter()
    assert [counter(), counter(), counter()] == [0, 1, 2]


def test_counters_are_independent():
    first = m.make_counter(10)
    second = m.make_counter(10)
    assert first() == 10
    assert first() == 11
    assert second() == 10
