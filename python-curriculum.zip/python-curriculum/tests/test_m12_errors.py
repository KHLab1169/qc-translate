import m12_errors as m
import pytest


def test_parse_positive_int_accepts_valid():
    assert m.parse_positive_int("42") == 42


def test_validation_error_is_a_value_error():
    assert issubclass(m.ValidationError, ValueError)


@pytest.mark.parametrize("bad", ["abc", "0", "-3", ""])
def test_parse_positive_int_rejects_invalid(bad):
    with pytest.raises(m.ValidationError):
        m.parse_positive_int(bad)


def test_error_message_mentions_the_input():
    with pytest.raises(m.ValidationError, match="abc"):
        m.parse_positive_int("abc")


def test_retry_returns_first_success():
    calls = []

    def flaky():
        calls.append(1)
        if len(calls) < 3:
            raise RuntimeError("not yet")
        return "ok"

    assert m.retry(flaky, attempts=5) == "ok"
    assert len(calls) == 3


def test_retry_reraises_after_exhausting_attempts():
    def always_fails():
        raise RuntimeError("nope")

    with pytest.raises(RuntimeError, match="nope"):
        m.retry(always_fails, attempts=2)


def test_collect_errors():
    def validator(value):
        if value < 0:
            raise ValueError(f"negative: {value}")

    assert m.collect_errors([1, -2, 3, -4], validator) == [
        (-2, "negative: -2"),
        (-4, "negative: -4"),
    ]
    assert m.collect_errors([1, 2], validator) == []
