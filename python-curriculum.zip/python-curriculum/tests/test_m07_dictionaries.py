import m07_dictionaries as m


def test_word_count():
    assert m.word_count("the cat the hat") == {"the": 2, "cat": 1, "hat": 1}
    assert m.word_count("Bug bug BUG") == {"bug": 3}
    assert m.word_count("") == {}


def test_invert():
    assert m.invert({"a": 1, "b": 2}) == {1: "a", 2: "b"}
    assert m.invert({}) == {}


def test_merge_defaults():
    defaults = {"retries": 3, "timeout": 30}
    overrides = {"timeout": 5}
    assert m.merge_defaults(defaults, overrides) == {"retries": 3, "timeout": 5}
    assert defaults == {"retries": 3, "timeout": 30}, "defaults must not be mutated"


def test_group_by_first_letter():
    assert m.group_by_first_letter(["ant", "Bee", "acorn"]) == {
        "a": ["ant", "acorn"],
        "b": ["Bee"],
    }
    assert m.group_by_first_letter([]) == {}
