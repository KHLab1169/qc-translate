"""Module 07 - Dictionaries: access, .get, .items, comprehensions."""


def word_count(text):
    """Count lowercase words in the text, returning a dict of word -> count."""
    raise NotImplementedError("TODO: implement word_count")


def invert(mapping):
    """Swap keys and values. Later keys win when values collide."""
    raise NotImplementedError("TODO: implement invert")


def merge_defaults(defaults, overrides):
    """Return a new dict with overrides applied on top of defaults.

    Neither input dict may be modified.
    """
    raise NotImplementedError("TODO: implement merge_defaults")


def group_by_first_letter(words):
    """Group words into a dict keyed by lowercase first letter, order preserved."""
    raise NotImplementedError("TODO: implement group_by_first_letter")
