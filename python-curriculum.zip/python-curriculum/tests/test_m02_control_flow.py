import m02_control_flow as m
import pytest


@pytest.mark.parametrize("score, expected", [
    (100, "A"), (90, "A"), (89, "B"), (75, "C"), (60, "D"), (59, "F"), (0, "F"),
])
def test_letter_grade(score, expected):
    assert m.letter_grade(score) == expected


@pytest.mark.parametrize("n, expected", [
    (1, "1"), (3, "Fizz"), (5, "Buzz"), (15, "FizzBuzz"), (30, "FizzBuzz"), (7, "7"),
])
def test_fizzbuzz(n, expected):
    assert m.fizzbuzz(n) == expected


def test_triage():
    assert m.triage("critical", False) == "P1"
    assert m.triage("critical", True) == "P1"
    assert m.triage("major", True) == "P2"
    assert m.triage("major", False) == "P3"
    assert m.triage("minor", True) == "P4"


def test_safe_divide():
    assert m.safe_divide(10, 4) == 2.5
    assert m.safe_divide(5, 0) is None
