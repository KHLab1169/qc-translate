"""Test configuration.

By default the tests grade the stub files in exercises/.
Run with SOLUTIONS=1 to grade the reference answers instead:

    SOLUTIONS=1 pytest -q
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).parent
SOURCE = "solutions" if os.environ.get("SOLUTIONS") else "exercises"
sys.path.insert(0, str(ROOT / SOURCE))
