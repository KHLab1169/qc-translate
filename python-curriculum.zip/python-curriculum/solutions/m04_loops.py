"""Module 04 - for, while, range, enumerate, break and continue."""


def count_vowels(text):
    """Count a, e, i, o and u in the text, case-insensitively."""
    return sum(1 for char in text.lower() if char in "aeiou")


def fibonacci(n):
    """Return a list of the first n Fibonacci numbers, starting 0, 1."""
    sequence = []
    current, following = 0, 1
    for _ in range(n):
        sequence.append(current)
        current, following = following, current + following
    return sequence


def first_failure_index(results):
    """Return the index of the first "FAIL" in a list of result strings.

    Return -1 if nothing failed. Stop looking once a failure is found.
    """
    for index, result in enumerate(results):
        if result == "FAIL":
            return index
    return -1


def collatz_steps(n):
    """Count steps to reach 1: halve if even, else 3n + 1. collatz_steps(1) == 0."""
    steps = 0
    while n != 1:
        n = n // 2 if n % 2 == 0 else 3 * n + 1
        steps += 1
    return steps
