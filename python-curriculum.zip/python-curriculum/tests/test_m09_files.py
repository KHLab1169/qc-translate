"""These tests use pytest's tmp_path fixture: a fresh temp directory per test."""
import json

import m09_files as m
import pytest


def test_write_lines(tmp_path):
    target = tmp_path / "out.txt"
    assert m.write_lines(target, ["alpha", "beta"]) == 2
    assert target.read_text(encoding="utf-8") == "alpha\nbeta\n"


def test_count_lines_matching(tmp_path):
    log = tmp_path / "run.log"
    log.write_text("INFO start\nERROR boom\nERROR again\n", encoding="utf-8")
    assert m.count_lines_matching(log, "ERROR") == 2
    assert m.count_lines_matching(log, "WARN") == 0


def test_read_json_field(tmp_path):
    config = tmp_path / "config.json"
    config.write_text(json.dumps({"retries": 3}), encoding="utf-8")
    assert m.read_json_field(config, "retries") == 3
    assert m.read_json_field(config, "missing") is None
    assert m.read_json_field(config, "missing", "fallback") == "fallback"


def test_csv_column_sum(tmp_path):
    report = tmp_path / "report.csv"
    report.write_text("suite,duration\nlogin,1.5\ncart,2.5\n", encoding="utf-8")
    assert m.csv_column_sum(report, "duration") == pytest.approx(4.0)
