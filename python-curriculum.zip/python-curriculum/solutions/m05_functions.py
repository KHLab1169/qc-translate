"""Module 05 - Functions: defaults, *args, **kwargs, closures, first-class functions."""


def apply_twice(func, value):
    """Call func on value, then call func on the result, and return it."""
    return func(func(value))


def summarize(*numbers):
    """Return (minimum, maximum, mean) for the numbers given.

    Return (None, None, None) when called with no arguments.
    """
    if not numbers:
        return (None, None, None)
    return (min(numbers), max(numbers), sum(numbers) / len(numbers))


def build_url(base, **params):
    """Append query parameters to a base URL, sorted by key.

    build_url("http://x.dev", b=2, a=1) -> "http://x.dev?a=1&b=2"
    With no params, return base unchanged.
    """
    if not params:
        return base
    query = "&".join(f"{key}={params[key]}" for key in sorted(params))
    return f"{base}?{query}"


def make_counter(start=0):
    """Return a function that returns start, start + 1, start + 2 ... on each call."""
    count = start - 1

    def counter():
        nonlocal count
        count += 1
        return count

    return counter
