"""Module 04 - for, while, range, enumerate, break and continue."""


def count_vowels(text):
    """Count a, e, i, o and u in the text, case-insensitively."""
    raise NotImplementedError("TODO: implement count_vowels")


def fibonacci(n):
    """Return a list of the first n Fibonacci numbers, starting 0, 1."""
    raise NotImplementedError("TODO: implement fibonacci")


def first_failure_index(results):
    """Return the index of the first "FAIL" in a list of result strings.

    Return -1 if nothing failed. Stop looking once a failure is found.
    """
    raise NotImplementedError("TODO: implement first_failure_index")


def collatz_steps(n):
    """Count steps to reach 1: halve if even, else 3n + 1. collatz_steps(1) == 0."""
    raise NotImplementedError("TODO: implement collatz_steps")
