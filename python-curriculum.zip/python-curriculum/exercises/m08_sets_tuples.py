"""Module 08 - Sets, tuples, unpacking and comprehensions."""


def common_tags(first, second):
    """Return a sorted list of the tags present in both collections."""
    raise NotImplementedError("TODO: implement common_tags")


def only_in_first(first, second):
    """Return a sorted list of the items in first but not in second."""
    raise NotImplementedError("TODO: implement only_in_first")


def squares_of_odds(n):
    """Return the squares of the odd numbers below n, using a comprehension."""
    raise NotImplementedError("TODO: implement squares_of_odds")


def adjacent_pairs(items):
    """Pair each item with the next: [1, 2, 3] -> [(1, 2), (2, 3)]."""
    raise NotImplementedError("TODO: implement adjacent_pairs")
