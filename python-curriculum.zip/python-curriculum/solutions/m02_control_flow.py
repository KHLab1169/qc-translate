"""Module 02 - Booleans, if/elif/else, comparison and logical operators."""


def letter_grade(score):
    """Map 0-100 to a letter: 90+ A, 80+ B, 70+ C, 60+ D, else F."""
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 60:
        return "D"
    return "F"


def fizzbuzz(n):
    """Return "Fizz", "Buzz", "FizzBuzz" or str(n) for an integer n."""
    if n % 15 == 0:
        return "FizzBuzz"
    if n % 3 == 0:
        return "Fizz"
    if n % 5 == 0:
        return "Buzz"
    return str(n)


def triage(severity, reproducible):
    """Return a bug priority string.

    severity is one of "critical", "major", "minor".
    Critical bugs are always "P1".
    Major bugs are "P2" when reproducible, otherwise "P3".
    Anything else is "P4".
    """
    if severity == "critical":
        return "P1"
    if severity == "major":
        return "P2" if reproducible else "P3"
    return "P4"


def safe_divide(a, b):
    """Return a / b, or None if b is zero. Use try/except rather than an if."""
    try:
        return a / b
    except ZeroDivisionError:
        return None
