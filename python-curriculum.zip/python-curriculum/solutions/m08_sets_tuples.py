"""Module 08 - Sets, tuples, unpacking and comprehensions."""


def common_tags(first, second):
    """Return a sorted list of the tags present in both collections."""
    return sorted(set(first) & set(second))


def only_in_first(first, second):
    """Return a sorted list of the items in first but not in second."""
    return sorted(set(first) - set(second))


def squares_of_odds(n):
    """Return the squares of the odd numbers below n, using a comprehension."""
    return [value * value for value in range(n) if value % 2 == 1]


def adjacent_pairs(items):
    """Pair each item with the next: [1, 2, 3] -> [(1, 2), (2, 3)]."""
    return list(zip(items, items[1:]))
