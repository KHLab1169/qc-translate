"""Module 12 - Exceptions: raising, catching, custom types and cleanup."""


class ValidationError(ValueError):
    """Raised when input fails validation."""


def parse_positive_int(text):
    """Return the int in text, or raise ValidationError with a helpful message.

    Both non-numeric text and values below 1 are invalid.
    """
    try:
        value = int(text)
    except (TypeError, ValueError):
        raise ValidationError(f"not a number: {text!r}") from None
    if value < 1:
        raise ValidationError(f"not positive: {value}")
    return value


def retry(func, attempts=3):
    """Call func until it returns without raising.

    Return its value on success. If every attempt raises, re-raise the last error.
    """
    last_error = None
    for _ in range(attempts):
        try:
            return func()
        except Exception as error:
            last_error = error
    raise last_error


def collect_errors(items, validator):
    """Run validator on each item and collect the failures.

    Return a list of (item, message) for the items that raised, in order.
    """
    failures = []
    for item in items:
        try:
            validator(item)
        except Exception as error:
            failures.append((item, str(error)))
    return failures
