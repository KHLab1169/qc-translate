import pytest
import m01_basics as m


def test_greet():
    assert m.greet("Ada") == "Hello, Ada!"
    assert m.greet("") == "Hello, !"


@pytest.mark.parametrize("celsius, expected", [(0, 32.0), (100, 212.0), (-40, -40.0), (37, 98.6)])
def test_celsius_to_fahrenheit(celsius, expected):
    assert m.celsius_to_fahrenheit(celsius) == pytest.approx(expected)


@pytest.mark.parametrize("seconds, expected", [
    (0, "0:00:00"), (61, "0:01:01"), (3661, "1:01:01"), (86399, "23:59:59"),
])
def test_seconds_to_hms(seconds, expected):
    assert m.seconds_to_hms(seconds) == expected


def test_pass_rate():
    assert m.pass_rate(1, 2) == 50.0
    assert m.pass_rate(2, 3) == 66.7
    assert m.pass_rate(0, 0) == 0.0
