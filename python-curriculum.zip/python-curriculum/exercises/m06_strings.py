"""Module 06 - String methods, slicing, split and join."""


def normalize_whitespace(text):
    """Collapse runs of whitespace into single spaces and strip the ends."""
    raise NotImplementedError("TODO: implement normalize_whitespace")


def is_palindrome(text):
    """True if the text reads the same backwards, ignoring case and punctuation."""
    raise NotImplementedError("TODO: implement is_palindrome")


def initials(full_name):
    """Return dotted uppercase initials: "ada lovelace" -> "A.L."

    An empty or whitespace-only name returns "".
    """
    raise NotImplementedError("TODO: implement initials")


def parse_log_line(line):
    """Split "2026-01-31 12:00:00 ERROR Disk full" into a dict.

    Returns {"date":..., "time":..., "level":..., "message":...}.
    The message keeps its internal spacing and may contain spaces.
    """
    raise NotImplementedError("TODO: implement parse_log_line")
