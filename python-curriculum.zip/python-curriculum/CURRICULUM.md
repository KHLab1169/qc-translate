# Python 3, Codecademy-style — with a test suite that grades you

A twelve-module core curriculum covering the same ground as *Learn Python 3*, plus a second track that turns that foundation into test-automation skill. Every module ships with stub functions and a pytest suite that tells you the moment you've got it right.

The whole thing is a red-to-green loop: run the tests, watch them fail, make them pass. You learn Python and pytest at the same time, which is the shortest path from "reading Python" to "writing Python other people run."

---

## How to use this

1. Read the module's concepts below and skim the linked reference.
2. Open `exercises/mNN_name.py`. Each function has a docstring describing exactly what it must do.
3. Run that module's tests. Read the failure. Fix. Repeat until green.
4. Do the checkpoint project in a scratch file — that's where the learning sticks.
5. Only then look at `solutions/mNN_name.py`.

```fish
python3 -m pytest tests/test_m01_basics.py -q     # one module
python3 -m pytest -q                              # everything
python3 progress.py                               # progress bars per module
```

Don't skip step 4. The graded exercises build recall; the projects build judgement. Passing all 85 checks without writing anything from a blank file will leave you able to read Python but not start it.

---

# Part 1 — Core Python

### Module 01 — Values, types, f-strings
`exercises/m01_basics.py` · 10 checks

Variables and assignment · `int` / `float` / `str` / `bool` · arithmetic and `//`, `%`, `**` · `divmod` · f-strings and format specs like `{n:02d}` · `round` · comments and docstrings · reading a traceback.

**Checkpoint** — a script that takes a duration in seconds and prints it four ways: raw, H:MM:SS, minutes with one decimal, and "about N minutes."

**Done when** you can explain why `0.1 + 0.2 != 0.3` and reach for `round` or `pytest.approx` without being told.

---

### Module 02 — Control flow
`exercises/m02_control_flow.py` · 15 checks

`if` / `elif` / `else` · comparison operators · `and`, `or`, `not` · truthiness of `""`, `0`, `[]`, `None` · the conditional expression `a if cond else b` · early returns instead of nested branches · a first `try` / `except`.

**Checkpoint** — a bug triage prompt: ask for severity, reproducibility and whether it's a regression, then print a priority and a one-line justification.

**Done when** you prefer a guard clause over a pyramid of nested `if`s, and you can say what `if items:` actually tests.

---

### Module 03 — Lists
`exercises/m03_lists.py` · 5 checks

Creating and indexing · negative indices · slicing including `[::-1]` and `[i:i+n]` · `append`, `extend`, `insert`, `remove`, `pop` · `sorted` vs `.sort()` · `sorted(key=...)` and `reverse=True` · `in` · list comprehensions · why mutating a caller's list is a bug.

**Checkpoint** — take a list of test durations and report the slowest five, the median, and anything over twice the average.

**Done when** the difference between `sorted(x)` and `x.sort()` is obvious to you, and you know why `def f(items=[])` is a trap.

---

### Module 04 — Loops
`exercises/m04_loops.py` · 10 checks

`for` over any iterable · `range` with three arguments · `while` · `break` and `continue` · `enumerate` · `zip` · nested loops · accumulator patterns · `sum` with a generator expression.

**Checkpoint** — a test-run summarizer: given a list of `(name, status, seconds)` tuples, print pass/fail counts, the pass rate, and the name of the first failure.

**Done when** you reach for `enumerate` instead of maintaining your own index counter.

---

### Module 05 — Functions
`exercises/m05_functions.py` · 5 checks

Parameters, arguments and return values · default arguments · keyword arguments · `*args` and `**kwargs` · local vs global scope · `nonlocal` and closures · functions as values · `lambda` · single responsibility.

**Checkpoint** — a small retry helper: given a function and a maximum attempt count, call it until it succeeds, printing each attempt.

**Done when** you can pass a function into another function without thinking twice about it.

---

### Module 06 — Strings
`exercises/m06_strings.py` · 7 checks

Immutability · indexing and slicing · `split`, `join`, `strip`, `replace` · `lower` / `upper` / `title` · `startswith`, `endswith`, `find` · `isalnum` and friends · `split(sep, maxsplit)` · f-string alignment · a first look at `re` (optional).

**Checkpoint** — parse a 20-line log file into structured records and print every ERROR with its timestamp.

**Done when** `" ".join(text.split())` reads as obvious to you, and you know why building strings in a loop with `+=` is a smell.

---

### Module 07 — Dictionaries
`exercises/m07_dictionaries.py` · 4 checks

Keys, values, lookup · `.get` with a default · `.items()`, `.keys()`, `.values()` · `.setdefault` · `.update` · dict comprehensions · nested dicts · counting patterns · shallow copy vs reference.

**Checkpoint** — read a JSON config, apply environment overrides on top of defaults, and print the resolved settings sorted by key.

**Done when** you use `.get(key, default)` instead of `try`/`except KeyError` for optional lookups, and you know `dict(a)` is a shallow copy.

---

### Module 08 — Sets, tuples, comprehensions
`exercises/m08_sets_tuples.py` · 4 checks

Sets and deduplication · union, intersection, difference · tuples and immutability · unpacking including `a, b = b, a` · returning multiple values · comprehensions with conditions · generator expressions and when they beat a list.

**Checkpoint** — compare two test runs and report tests that were added, removed, and newly failing.

**Done when** "which items are in A but not B" makes you reach for a set instead of a nested loop.

---

### Module 09 — Files, CSV, JSON
`exercises/m09_files.py` · 4 checks

`open` modes · the `with` statement and why it matters · iterating a file lazily · `csv.DictReader` and `DictWriter` · `json.load` / `dump` / `dumps` · encodings · `pathlib.Path` basics · pytest's `tmp_path` fixture.

**Checkpoint** — read a CSV of test results, write a JSON summary, and print the three slowest suites.

**Done when** you never write `f = open(...)` without a `with` again.

---

### Module 10 — Classes
`exercises/m10_classes.py` · 6 checks

`class`, `__init__`, `self` · instance vs class attributes · methods · `__repr__`, `__eq__`, `__len__` · inheritance and `super()` · `@property` · `isinstance` · when a class earns its place over a function or a dict · `@dataclass` as the modern shortcut.

**Checkpoint** — model a `TestSuite` that holds `TestCase` objects, can add and run them, and reports pass rate and total duration.

**Done when** you can explain what `self` is to someone else, and why a good `__repr__` saves you debugging time.

---

### Module 11 — The standard library
`exercises/m11_stdlib.py` · 5 checks

`import` forms and module search · `datetime` and `timedelta` · `collections.Counter` and `defaultdict` · `pathlib` for filesystem work · `random` with a seed for reproducibility · `os.environ` · `itertools` highlights · `argparse` for CLIs.

**Checkpoint** — a CLI that scans a directory for `.log` files and prints the top error messages across all of them.

**Done when** you check whether the standard library already solves it before writing the loop yourself.

---

### Module 12 — Exceptions
`exercises/m12_errors.py` · 10 checks

The exception hierarchy · `raise` · `try` / `except` / `else` / `finally` · catching specific types, never bare `except:` · custom exception classes · exception chaining with `from` · `assert` and where it belongs · error messages that name the offending value.

**Checkpoint** — a config validator that collects *every* problem before raising, rather than failing on the first one.

**Done when** your error messages include the bad input, and you can say why `except Exception:` is usually a bug in waiting.

---

**Capstone for Part 1 — a mini test runner.** Discover functions named `test_*` in a module, run each one, catch failures, time them, and print a summary with a pass rate and non-zero exit code on failure. It touches every module above, and building one teaches you more about pytest than any tutorial will.

---

# Part 2 — From Python to test automation

Part 1 gets you to "I can write Python." Part 2 is the part that shows up in job descriptions. No stub files here — these are project-shaped, and the deliverable is a repository you can point at.

### Module 13 — Environments and project layout
`venv` and why it isn't optional · `pip install`, `pip freeze`, `requirements.txt` · `pyproject.toml` · `src/` layout · imports and `__init__.py` · `.gitignore`.

**Deliverable** — the Part 1 capstone, restructured as an installable package with a pinned requirements file.

### Module 14 — pytest for real
Discovery rules · `assert` introspection · fixtures and scopes · `conftest.py` · `@pytest.mark.parametrize` · markers and `-m` · `pytest.raises` · `tmp_path`, `capsys`, `monkeypatch` · `pytest-cov` · `-x`, `-k`, `-vv`, `--lf`.

**Deliverable** — go back and rewrite three of this curriculum's own test files from scratch, then compare with the originals.

### Module 15 — Type hints and tooling
Annotations · `Optional`, `list[str]`, `dict[str, int]` · `mypy` · `ruff` for linting and formatting · pre-commit hooks.

**Deliverable** — a clean `mypy` and `ruff` run over your package, wired into a pre-commit hook.

### Module 16 — API testing
`requests` / `httpx` · status codes, headers, JSON bodies · sessions and auth · retries and timeouts · response schema validation with `pydantic` · fixtures for test data · `responses` for stubbing.

**Deliverable** — a suite against a public API covering happy path, auth failure, bad input, and pagination.

### Module 17 — Mocking and test doubles
`unittest.mock.Mock` and `patch` · patching where it's *used*, not where it's defined · `monkeypatch` · `freezegun` for time · faking network and filesystem · when a mock is a liability.

**Deliverable** — add unit tests to the Module 16 suite that run fully offline.

### Module 18 — Browser automation and CI
Playwright for Python · locators and auto-waiting · the page object pattern · traces and screenshots on failure · parallelism with `pytest-xdist` · flakiness and quarantine strategy · GitHub Actions running the suite on every push.

**Deliverable** — a small end-to-end suite with a CI badge that goes red when it should.

---

## A workable schedule

| Weeks | Work |
|---|---|
| 1 | Modules 01–04 |
| 2 | Modules 05–08 |
| 3 | Modules 09–12 |
| 4 | Part 1 capstone |
| 5–8 | Modules 13–18, roughly one per few days |

Sixty to ninety minutes a day beats a five-hour Saturday. If a module's checks go green in twenty minutes, don't linger — do the checkpoint project and move on.

## Habits worth building early

- **Read the whole traceback, bottom-up.** The last line names the error; the lines above name the path to it.
- **Use the REPL.** `python3` with no arguments, then poke at things. `dir(obj)` and `help(obj)` are faster than a search.
- **Name things for what they are.** `failed_cases`, not `fc` or `list2`.
- **Commit after each green module.** Small commits make the history a study log.
- **Rewrite one exercise a week from memory.** Recall, not recognition, is what survives a technical screen.

## Where to look things up

- The official tutorial: <https://docs.python.org/3/tutorial/>
- Library reference: <https://docs.python.org/3/library/>
- pytest docs: <https://docs.pytest.org/>
- *Automate the Boring Stuff* (free online) for extra drills on files and strings
