import m04_loops as m
import pytest


def test_count_vowels():
    assert m.count_vowels("Regression") == 4
    assert m.count_vowels("AEIOU") == 5
    assert m.count_vowels("rhythm") == 0


@pytest.mark.parametrize("n, expected", [
    (0, []), (1, [0]), (2, [0, 1]), (7, [0, 1, 1, 2, 3, 5, 8]),
])
def test_fibonacci(n, expected):
    assert m.fibonacci(n) == expected


def test_first_failure_index():
    assert m.first_failure_index(["PASS", "FAIL", "FAIL"]) == 1
    assert m.first_failure_index(["PASS", "PASS"]) == -1
    assert m.first_failure_index([]) == -1


@pytest.mark.parametrize("n, expected", [(1, 0), (2, 1), (6, 8), (27, 111)])
def test_collatz_steps(n, expected):
    assert m.collatz_steps(n) == expected
