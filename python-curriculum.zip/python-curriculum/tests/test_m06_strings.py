import m06_strings as m
import pytest


def test_normalize_whitespace():
    assert m.normalize_whitespace("  a   b \n c ") == "a b c"
    assert m.normalize_whitespace("") == ""
    assert m.normalize_whitespace("solo") == "solo"


@pytest.mark.parametrize("text, expected", [
    ("racecar", True),
    ("A man, a plan, a canal: Panama", True),
    ("regression", False),
    ("", True),
])
def test_is_palindrome(text, expected):
    assert m.is_palindrome(text) is expected


def test_initials():
    assert m.initials("ada lovelace") == "A.L."
    assert m.initials("Grace Brewster Hopper") == "G.B.H."
    assert m.initials("   ") == ""


def test_parse_log_line():
    parsed = m.parse_log_line("2026-01-31 12:00:00 ERROR Disk full on node 3")
    assert parsed == {
        "date": "2026-01-31",
        "time": "12:00:00",
        "level": "ERROR",
        "message": "Disk full on node 3",
    }
