from datetime import date

import m11_stdlib as m


def test_days_between():
    assert m.days_between(date(2026, 1, 1), date(2026, 1, 31)) == 30
    assert m.days_between(date(2026, 1, 31), date(2026, 1, 1)) == 30
    assert m.days_between(date(2026, 5, 5), date(2026, 5, 5)) == 0


def test_parse_iso_date():
    assert m.parse_iso_date("2026-01-31") == date(2026, 1, 31)


def test_most_common_levels():
    lines = ["ERROR a", "INFO b", "ERROR c", "WARN d", "ERROR e", "INFO f"]
    assert m.most_common_levels(lines, 2) == [("ERROR", 3), ("INFO", 2)]
    assert m.most_common_levels(lines, 1) == [("ERROR", 3)]


def test_deterministic_sample_repeats():
    items = list(range(50))
    first = m.deterministic_sample(items, 5, seed=42)
    second = m.deterministic_sample(items, 5, seed=42)
    assert first == second
    assert len(first) == 5
    assert set(first) <= set(items)


def test_find_files(tmp_path):
    (tmp_path / "pkg").mkdir()
    (tmp_path / "a.py").write_text("")
    (tmp_path / "pkg" / "b.py").write_text("")
    (tmp_path / "notes.txt").write_text("")
    assert m.find_files(tmp_path, ".py") == ["a.py", "pkg/b.py"]
