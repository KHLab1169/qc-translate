"""Module 10 - Classes, dunder methods, inheritance and properties."""


class Stack:
    """A last-in first-out stack built on a list."""

    def __init__(self):
        """Start with an empty stack."""
        raise NotImplementedError("TODO: implement __init__")

    def push(self, item):
        """Add an item to the top."""
        raise NotImplementedError("TODO: implement push")

    def pop(self):
        """Remove and return the top item, or None when empty."""
        raise NotImplementedError("TODO: implement pop")

    def peek(self):
        """Return the top item without removing it, or None when empty."""
        raise NotImplementedError("TODO: implement peek")

    def __len__(self):
        """Support len(stack)."""
        raise NotImplementedError("TODO: implement __len__")


class TestCase:
    """A named test case with an ordered list of steps."""

    def __init__(self, name, steps=None):
        """Store the name and a copy of any starting steps."""
        raise NotImplementedError("TODO: implement __init__")

    def add_step(self, step):
        """Append a step and return self so calls can be chained."""
        raise NotImplementedError("TODO: implement add_step")

    def __len__(self):
        """The number of steps."""
        raise NotImplementedError("TODO: implement __len__")

    def __repr__(self):
        """Return e.g. TestCase('Login', steps=2)."""
        raise NotImplementedError("TODO: implement __repr__")

    def __eq__(self, other):
        """Two test cases are equal when name and steps match."""
        raise NotImplementedError("TODO: implement __eq__")


class TimedTestCase(TestCase):
    """A test case that also records how long it ran, in seconds."""

    def __init__(self, name, duration, steps=None):
        """Call the parent initialiser, then store the duration."""
        raise NotImplementedError("TODO: implement __init__")

    @property
    def is_slow(self):
        """True when the run took longer than 30 seconds."""
        raise NotImplementedError("TODO: implement is_slow")

    def __repr__(self):
        """Return e.g. TimedTestCase('Login', 12.5s, steps=2)."""
        raise NotImplementedError("TODO: implement __repr__")
