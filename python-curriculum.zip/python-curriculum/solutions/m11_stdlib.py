"""Module 11 - The standard library: datetime, collections, pathlib, random."""
import random
from collections import Counter
from datetime import date
from pathlib import Path


def days_between(first, second):
    """Return the absolute number of days between two date objects."""
    return abs((second - first).days)


def parse_iso_date(text):
    """Parse "2026-01-31" into a date object."""
    return date.fromisoformat(text)


def most_common_levels(lines, n):
    """Return the n most common log levels as (level, count) pairs.

    Each line looks like "ERROR something happened"; the level is the first word.
    """
    levels = Counter(line.split()[0] for line in lines)
    return levels.most_common(n)


def deterministic_sample(items, k, seed):
    """Return k items chosen with a seeded Random instance, so runs repeat."""
    return random.Random(seed).sample(list(items), k)


def find_files(root, suffix):
    """Return sorted relative path strings of files under root with that suffix."""
    root_path = Path(root)
    matches = sorted(root_path.rglob(f"*{suffix}"))
    return [str(match.relative_to(root_path)) for match in matches]
