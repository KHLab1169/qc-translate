"""Module 07 - Dictionaries: access, .get, .items, comprehensions."""


def word_count(text):
    """Count lowercase words in the text, returning a dict of word -> count."""
    counts = {}
    for word in text.lower().split():
        counts[word] = counts.get(word, 0) + 1
    return counts


def invert(mapping):
    """Swap keys and values. Later keys win when values collide."""
    return {value: key for key, value in mapping.items()}


def merge_defaults(defaults, overrides):
    """Return a new dict with overrides applied on top of defaults.

    Neither input dict may be modified.
    """
    merged = dict(defaults)
    merged.update(overrides)
    return merged


def group_by_first_letter(words):
    """Group words into a dict keyed by lowercase first letter, order preserved."""
    groups = {}
    for word in words:
        groups.setdefault(word[0].lower(), []).append(word)
    return groups
